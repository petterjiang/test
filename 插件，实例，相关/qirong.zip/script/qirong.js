$(function () {
	$(window).scroll(function(e) {
		var leftNavTop = $(".leftNav").offset().top;
		if ($.browser.webkit) {
			var docTop = $("body").scrollTop();
		}else{
			var docTop = $("html,body").scrollTop();
		}
		
		var top1 = $(".bgleft1").offset().top;
		var top2 = $(".bgleft2").offset().top;
		var top3 = $(".bgleft3").offset().top;
		var top4 = $(".bgleft4").offset().top;
		var top5 = $(".bottomshow").offset().top;
		// alert(docTop)
		if (docTop > 472) {
			$(".leftNav").css({
				"position": 'fixed',
				"top": '0'
			});
			
			
			if (docTop <= top5+100) {
				$(".leftNav ul li a").removeClass('onChang');
				$(".leftNav ul li a").eq(4).addClass('onChang');
			};
			if (docTop <= top4+100) {
				$(".leftNav ul li a").removeClass('onChang');
				$(".leftNav ul li a").eq(3).addClass('onChang');
			};
			if (docTop <= top3+100) {
				$(".leftNav ul li a").removeClass('onChang');
				$(".leftNav ul li a").eq(2).addClass('onChang');
			};
			if (docTop <= top2+100) {
				$(".leftNav ul li a").removeClass('onChang');
				$(".leftNav ul li a").eq(1).addClass('onChang');
			};
			if (docTop <= top1+100 ) {
				$(".leftNav ul li a").removeClass('onChang');
				$(".leftNav ul li a").eq(0).addClass('onChang');
			};
			
		}else{
			$(".leftNav").css({
				"position": 'absolute',
				"top": '472px'
			});
			$(".leftNav ul li a").removeClass('onChang');
		}
		
	});
	$(".leftNav a").click(function(e) {
		e.preventDefault();
	});

	$(".goTop").click(function(event) {
		$(".leftNav ul").addClass('noChang');
		$("html,body").animate({"scrollTop":0}, 300,function () {
			$(".leftNav ul").removeClass('noChang');
		})
	});

	$(".leftNav ul li a").click(function(e) {
		var thisRel = $(this).attr("rel");
		var relTop = $("."+thisRel).offset().top;
		var thiObj = $(this);
		thiObj.addClass('clickA')
		$(".leftNav ul").addClass('noChang');
		$("html,body").animate({"scrollTop":relTop}, 200,function () {
			$(".leftNav ul").removeClass('noChang');
			thiObj.addClass('onChang').parent().siblings().find('a').removeClass('onChang');
			thiObj.removeClass('clickA')
		});
	});
})